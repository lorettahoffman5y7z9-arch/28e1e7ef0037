// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute ground track\n", stdout);
  return lionss_run_workload("groundTrack");
}
