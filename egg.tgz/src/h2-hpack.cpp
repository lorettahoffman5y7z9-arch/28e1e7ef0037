// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compress header block"); }
int main(){
  announce();
  return lionss_run_workload("h2-hpack");
}
