// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Freeze cgroup tasks"); }
int main(){
  announce();
  return lionss_run_workload("cgroupFreeze");
}
