// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Vacuum dead versions\n", stdout);
  return lionss_run_workload("mvccVacuum");
}
